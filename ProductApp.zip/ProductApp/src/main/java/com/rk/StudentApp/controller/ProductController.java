package com.rk.StudentApp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rk.StudentApp.entity.ProductEntity;
import com.rk.StudentApp.service.ProductService;
import com.rk.StudentApp.vo.ProductDescriptionVO;

@RestController
@RequestMapping("product")
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@GetMapping("/getall")
	public List<ProductEntity> getAll() {
		return productService.getAll();
	}
	@GetMapping("/description/{id}")
	public Optional<ProductDescriptionVO> getMarks(@PathVariable Integer id) {
		return productService.getWithProductFeign(id);
	}
	@PostMapping("/saveproduct")
	public ProductEntity addProduct(@RequestBody ProductEntity entity) {
		return productService.addProduct(entity);
	}
	@GetMapping("/getbyid/{id}")
	public Optional<ProductEntity> getbyId(@PathVariable("id") Integer id) {
		return productService.getbyId(id);
	}
	@GetMapping("/getbytype/{type}")
	public List<ProductEntity> getbyType(@PathVariable("type") String type) {
		return productService.getbyType(type);
	}
}
