package com.rk.StudentApp.service;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.rk.StudentApp.vo.ProductDescriptionVO;

@FeignClient(url = "http://localhost:1724", value="product")
public interface ProductDescriptionClient {

	@GetMapping("description/getbyid/{id}")
	public Optional<ProductDescriptionVO> getMarks(@PathVariable Integer id);
}
